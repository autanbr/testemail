package br.Email;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.SimpleEmail; 

public class Email {

	
	public void sendEmail() throws EmailException {
		SimpleEmail  email = new SimpleEmail();
		System.out.println("alterando hostname...");
		email.setHostName("smtp.gmail.com");
		email.setSmtpPort(465);
	
		email.addTo("vilog_6@msn.com", "vinicius");
		email.setFrom("autanbr@gmail.com","autanbr");
		email.setSubject("Vagas de Empregos");
		email.setMsg("vagas programador dotNet");
		System.out.println("autenticando...");
		email.setSSLOnConnect(true);
		email.setAuthentication("autanbr@gmail.com", "!(*)vinicius");
		System.out.println("enviando...");
		email.send();
	}

}
