package br.Email;



public class SaidaEmail extends EmailNovo{

	 public static void main(String[] args) 
	    {
		 
	        String to = "vilog6@gmail.com";
	        sendEmail(to);
	    }

}
